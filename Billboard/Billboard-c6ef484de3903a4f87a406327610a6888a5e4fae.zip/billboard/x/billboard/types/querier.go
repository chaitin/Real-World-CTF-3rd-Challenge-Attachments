package types

const QueryListAdvertisement = "list-advertisement"
const QueryGetAdvertisement = "get-advertisement"
